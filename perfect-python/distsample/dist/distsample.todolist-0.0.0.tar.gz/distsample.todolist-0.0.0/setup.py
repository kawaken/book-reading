from setuptools import setup

setup(
        name="distsample.todolist",
        packages=['distsample.todolist'],
)
